pragma solidity >= 0.8.11 <= 0.8.11;
pragma experimental ABIEncoderV2;
//Lease solidity code
contract Lease {

    uint public leaseCount = 0; 
    mapping(uint => lease) public leaseList; 
     struct lease
     {
       string pid;
       string owner;
       string email;
       string property_address;
       string owning_type;
       string property_value;
       string purchase_date;
       string property_image;
       string available_loan;       
     }
 
   // events 
   event leaseCreated(uint indexed _leaseId);

    function updateLoan(uint i, string memory value) public { 
      leaseList[i].available_loan = value;
   }
  
   //function  to save lease details
   function createLease(string memory pid1, string memory owner1, string memory email1, string memory property_address1, string memory owning_type1, string memory property_value1, string memory purchase_date1, string memory property_image1, string memory available_loan1) public {
      leaseList[leaseCount] = lease(pid1, owner1, email1, property_address1, owning_type1, property_value1, purchase_date1, property_image1, available_loan1);
      emit leaseCreated(leaseCount);
      leaseCount++;
    }

     //get lease count
    function getLeaseCount()  public view returns (uint) {
          return  leaseCount;
    }

    function getPid(uint i) public view returns (string memory) {
        lease memory chq = leaseList[i];
	return chq.pid;
    }

    function getOwner(uint i) public view returns (string memory) {
        lease memory chq = leaseList[i];
	return chq.owner;
    }

    function getEmail(uint i) public view returns (string memory) {
        lease memory chq = leaseList[i];
	return chq.email;
    }

    function getPropertyAddress(uint i) public view returns (string memory) {
        lease memory chq = leaseList[i];
	return chq.property_address;
    }

    function getOwningType(uint i) public view returns (string memory) {
        lease memory chq = leaseList[i];
	return chq.owning_type;
    }

    function getPropertyValue(uint i) public view returns (string memory) {
        lease memory chq = leaseList[i];
	return chq.property_value;
    }

    function getPurchaseDate(uint i) public view returns (string memory) {
        lease memory chq = leaseList[i];
	return chq.purchase_date;
    }

    function getLoan(uint i) public view returns (string memory) {
        lease memory chq = leaseList[i];
	return chq.available_loan;
    }

     function getImage(uint i) public view returns (string memory) {
        lease memory chq = leaseList[i];
	return chq.property_image;
    }

          
       
    uint public userCount = 0; 
    mapping(uint => user) public usersList; 
     struct user
     {
       string username;
       string password;
       string phone;
       string usertype;
     }
 
   // events
 
   event userCreated(uint indexed _userId);
 
  function createUser(string memory _username, string memory _password, string memory _phone, string memory _utype) public {
      usersList[userCount] = user(_username, _password, _phone, _utype);
      emit userCreated(userCount);
      userCount++;
    }

    
     //get user count
    function getUserCount()  public view returns (uint) {
          return  userCount;
    }

    function getUsername(uint i) public view returns (string memory) {
        user memory usr = usersList[i];
	return usr.username;
    }

    function getPassword(uint i) public view returns (string memory) {
        user memory usr = usersList[i];
	return usr.password;
    }

    function getUserType(uint i) public view returns (string memory) {
        user memory usr = usersList[i];
	return usr.usertype;
    }
}