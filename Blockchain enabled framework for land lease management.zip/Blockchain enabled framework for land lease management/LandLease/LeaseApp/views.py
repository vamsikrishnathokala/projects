from django.shortcuts import render
from django.template import RequestContext
from django.contrib import messages
from django.http import HttpResponse
from django.core.files.storage import FileSystemStorage
import os
from datetime import date
import os
import json
from web3 import Web3, HTTPProvider
import os
import pickle
import smtplib

global username
global contract, web3, product_name
global usersList, leaseList, usertype

#function to call contract
def getContract():
    global contract, web3
    blockchain_address = 'http://127.0.0.1:8545'
    web3 = Web3(HTTPProvider(blockchain_address))
    web3.eth.defaultAccount = web3.eth.accounts[0]
    compiled_contract_path = 'Lease.json' #Lease contract file
    deployed_contract_address = '0x186829175efe2045730D6b6533015dA9Fc9F7CA1' #contract address
    with open(compiled_contract_path) as file:
        contract_json = json.load(file)  # load contract info as JSON
        contract_abi = contract_json['abi']  # fetch contract's abi - necessary to call its functions
    file.close()
    contract = web3.eth.contract(address=deployed_contract_address, abi=contract_abi)
getContract()

def getUsersList():
    global usersList, contract
    usersList = []
    count = contract.functions.getUserCount().call()
    for i in range(0, count):
        user = contract.functions.getUsername(i).call()
        password = contract.functions.getPassword(i).call()
        utype = contract.functions.getUserType(i).call()
        usersList.append([user, password, utype])

def getLeaseList():
    global leaseList, contract
    leaseList = []
    count = contract.functions.getLeaseCount().call()
    for i in range(0, count):
        pid = contract.functions.getPid(i).call()
        owner = contract.functions.getOwner(i).call()
        email = contract.functions.getEmail(i).call()
        address = contract.functions.getPropertyAddress(i).call()
        owning = contract.functions.getOwningType(i).call()
        value = contract.functions.getPropertyValue(i).call()
        purchase_date = contract.functions.getPurchaseDate(i).call()
        image = contract.functions.getImage(i).call()
        loan = contract.functions.getLoan(i).call()
        leaseList.append([pid, owner, email, address, owning, value, purchase_date, image, loan])
getUsersList()
getLeaseList()

def AdminMap(request):
    if request.method == 'GET':
        name = request.GET.get('t1', False)
        output = '<iframe width="625" height="650" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?q='+name+'&amp;ie=UTF8&amp;&amp;output=embed"></iframe><br/>'
        context= {'data':output}
        return render(request, 'AdminScreen.html', context)

def PropertyValidationAction(request):
    if request.method == 'POST':
        global username, leaseList
        pid = request.POST.get('t1', False)
        output = '<table border=1 align=center>'
        output+='<tr><th><font size=3 color=black>Property ID</font></th>'
        output+='<th><font size=3 color=black>Owner Name</font></th>'
        output+='<th><font size=3 color=black>Email ID</font></th>'
        output+='<th><font size=3 color=black>Property Address</font></th>'
        output+='<th><font size=3 color=black>Owning Type</font></th>'
        output+='<th><font size=3 color=black>Property Value</font></th>'
        output+='<th><font size=3 color=black>Purchase Date</font></th>'
        output+='<th><font size=3 color=black>Property Image</font></th>'
        output+='<th><font size=3 color=black>Loan/Lease Details</font></th>'
        output+='<th><font size=3 color=black>View on Map</font></th></tr>'
        for i in range(len(leaseList)):
            plist = leaseList[i]
            if plist[0] == pid:
                output+='<tr><td><font size=3 color=black>'+plist[0]+'</font></td>'
                output+='<td><font size=3 color=black>'+plist[1]+'</font></td>'
                output+='<td><font size=3 color=black>'+str(plist[2])+'</font></td>'
                output+='<td><font size=3 color=black>'+str(plist[3])+'</font></td>'
                output+='<td><font size=3 color=black>'+str(plist[4])+'</font></td>'
                output+='<td><font size=3 color=black>'+str(plist[5])+'</font></td>'
                output+='<td><font size=3 color=black>'+str(plist[6])+'</font></td>'
                output+='<td><img src="/static/property/'+plist[7]+'" width="200" height="200"></img></td>'
                output+='<td><font size=3 color=black>'+str(plist[8])+'</font></td>'
                output+='<td><a href=\'AdminMap?t1='+str(plist[3])+'\'><font size=3 color=black>View on Map</font></a></td></tr>'                
        output+="</table><br/><br/><br/><br/><br/><br/>"
        context= {'data':output}
        return render(request, 'UserScreen.html', context)        

def sendNotification(email, notification):
    em = []
    em.append(email)
    with smtplib.SMTP_SSL('smtp.gmail.com', 465) as connection:
        email_address = 'kaleem202120@gmail.com'
        email_password = 'xyljzncebdxcubjq'
        connection.login(email_address, email_password)
        connection.sendmail(from_addr="kaleem202120@gmail.com", to_addrs=em, msg="Subject : loan Notification Mail\n"+notification)    

def RequestLeaseAction(request):
    if request.method == 'POST':
        global username, leaseList, contract
        pid = request.POST.get('t1', False)
        amount = "Lease Amount = 0. As loan already exists against this property"
        email = ""
        output = '<table border=1 align=center>'
        output+='<tr><th><font size=3 color=black>Property ID</font></th>'
        output+='<th><font size=3 color=black>Owner Name</font></th>'
        output+='<th><font size=3 color=black>Email ID</font></th>'
        output+='<th><font size=3 color=black>Property Address</font></th>'
        output+='<th><font size=3 color=black>Owning Type</font></th>'
        output+='<th><font size=3 color=black>Property Value</font></th>'
        output+='<th><font size=3 color=black>Purchase Date</font></th>'
        output+='<th><font size=3 color=black>Property Image</font></th>'
        output+='<th><font size=3 color=black>Loan/Lease Details</font></th>'
        output+='<th><font size=3 color=black>View on Map</font></th></tr>'
        for i in range(len(leaseList)):
            plist = leaseList[i]
            if plist[0] == pid:
                output+='<tr><td><font size=3 color=black>'+plist[0]+'</font></td>'
                output+='<td><font size=3 color=black>'+plist[1]+'</font></td>'
                output+='<td><font size=3 color=black>'+str(plist[2])+'</font></td>'
                output+='<td><font size=3 color=black>'+str(plist[3])+'</font></td>'
                output+='<td><font size=3 color=black>'+str(plist[4])+'</font></td>'
                output+='<td><font size=3 color=black>'+str(plist[5])+'</font></td>'
                output+='<td><font size=3 color=black>'+str(plist[6])+'</font></td>'
                output+='<td><img src="/static/property/'+plist[7]+'" width="200" height="200"></img></td>'
                output+='<td><font size=3 color=black>'+str(plist[8])+'</font></td>'
                output+='<td><a href=\'AdminMap?t1='+str(plist[3])+'\'><font size=3 color=black>View on Map</font></a></td></tr>'
                if plist[8] == 'No':
                    total = float(plist[5]) * 0.8
                    amount = "Loan Amount Sanctioned for your Property = "+str(total)
                    email = plist[2]
                    sendNotification(email,amount)
                    contract.functions.updateLoan(i, "Yes").transact()
                    plist[8] = "Yes"
                else:
                    email = plist[2]
                    sendNotification(email,amount)
                output+='<tr><td><font size=3 color=black>'+amount+'</font></td>'
        output+="</table><br/><br/><br/><br/><br/><br/>"
        context= {'data':output}
        return render(request, 'BankScreen.html', context)          

def ViewProperty(request):
    if request.method == 'GET':
        global leaseList
        output = '<table border=1 align=center>'
        output+='<tr><th><font size=3 color=black>Property ID</font></th>'
        output+='<th><font size=3 color=black>Owner Name</font></th>'
        output+='<th><font size=3 color=black>Email ID</font></th>'
        output+='<th><font size=3 color=black>Property Address</font></th>'
        output+='<th><font size=3 color=black>Owning Type</font></th>'
        output+='<th><font size=3 color=black>Property Value</font></th>'
        output+='<th><font size=3 color=black>Purchase Date</font></th>'
        output+='<th><font size=3 color=black>Property Image</font></th>'
        output+='<th><font size=3 color=black>Loan/Lease Details</font></th>'
        output+='<th><font size=3 color=black>View on Map</font></th></tr>'
        for i in range(len(leaseList)):
            plist = leaseList[i]
            output+='<tr><td><font size=3 color=black>'+plist[0]+'</font></td>'
            output+='<td><font size=3 color=black>'+plist[1]+'</font></td>'
            output+='<td><font size=3 color=black>'+str(plist[2])+'</font></td>'
            output+='<td><font size=3 color=black>'+str(plist[3])+'</font></td>'
            output+='<td><font size=3 color=black>'+str(plist[4])+'</font></td>'
            output+='<td><font size=3 color=black>'+str(plist[5])+'</font></td>'
            output+='<td><font size=3 color=black>'+str(plist[6])+'</font></td>'
            output+='<td><img src="/static/property/'+plist[7]+'" width="200" height="200"></img></td>'
            output+='<td><font size=3 color=black>'+str(plist[8])+'</font></td>'
            output+='<td><a href=\'AdminMap?t1='+str(plist[3])+'\'><font size=3 color=black>View on Map</font></a></td></tr>'       
        output+="</table><br/><br/><br/><br/><br/><br/>"
        context= {'data':output}
        return render(request, 'AdminScreen.html', context)  

def AddPropertyAction(request):
    if request.method == 'POST':
        global username, leaseList
        owner = request.POST.get('t1', False)
        email = request.POST.get('t2', False)
        address = request.POST.get('t3', False)
        owning = request.POST.get('t4', False)
        value = request.POST.get('t5', False)
        purchase_date = request.POST.get('t6', False)        
        image = request.FILES['t7']
        imagename = request.FILES['t7'].name
        pid = str((len(leaseList) + 1))
        fs = FileSystemStorage()
        msg = contract.functions.createLease(pid, owner, email, address, owning, value, purchase_date, imagename, "No").transact()
        tx_receipt = web3.eth.waitForTransactionReceipt(msg)
        if os.path.exists('LeaseApp/static/property/'+imagename):
            os.remove('LeaseApp/static/property/'+imagename)
        filename = fs.save('LeaseApp/static/property/'+imagename, image)
        leaseList.append([pid, owner, email, address, owning, value, purchase_date, imagename, "No"])
        context= {'data':"Property details saved in Blockchain with PID = "+pid+"<br/><br/>"+str(tx_receipt)}
        return render(request, 'AddProperty.html', context)        

def AdminLoginAction(request):
    if request.method == 'POST':
        global username, contract, usersList
        username = request.POST.get('t1', False)
        password = request.POST.get('t2', False)
        status = "AdminLogin.html"
        output = 'Invalid login details'
        if username == 'admin' and password == 'admin':
            context = {'data':"Welcome "+username}
            status = "AdminScreen.html"
            output = 'Welcome '+username             
        context= {'data':output}
        return render(request, status, context)
    
def index(request):
    if request.method == 'GET':
       return render(request, 'index.html', {})    

def AdminLogin(request):
    if request.method == 'GET':
       return render(request, 'AdminLogin.html', {})
    
def Register(request):
    if request.method == 'GET':
       return render(request, 'Register.html', {})

def BankLogin(request):
    if request.method == 'GET':
       return render(request, 'BankLogin.html', {})

def AddProperty(request):
    if request.method == 'GET':
        return render(request, 'AddProperty.html', {})

def RequestLease(request):
    if request.method == 'GET':
       return render(request, 'RequestLease.html', {})

def PropertyValidation(request):
    if request.method == 'GET':
       return render(request, 'PropertyValidation.html', {})    
    
def BankLoginAction(request):
    if request.method == 'POST':
        global username, contract, usersList, usertype
        username = request.POST.get('t1', False)
        password = request.POST.get('t2', False)
        status = "BankLogin.html"
        output = 'Invalid login details'
        for i in range(len(usersList)):
            ulist = usersList[i]
            user1 = ulist[0]
            pass1 = ulist[1]
            if user1 == username and pass1 == password:
                output = 'Welcome '+username+"<br/>User Type : "+ulist[2]
                if ulist[2] == 'Bank':
                    usertype = 'Bank'
                    status = 'BankScreen.html'
                elif ulist[2] == 'User':
                    usertype = 'User'
                    status = 'UserScreen.html'
                break            
        context= {'data':output}
        return render(request, status, context)

def RegisterAction(request):
    if request.method == 'POST':
        global usersList
        username = request.POST.get('t1', False)
        password = request.POST.get('t2', False)
        contact = request.POST.get('t3', False)
        utype = request.POST.get('t4', False)
        count = contract.functions.getUserCount().call()
        status = "none"
        for i in range(0, count):
            user1 = contract.functions.getUsername(i).call()
            if username == user1:
                status = "exists"
                break
        if status == "none":
            msg = contract.functions.createUser(username, password, contact, utype).transact()
            tx_receipt = web3.eth.waitForTransactionReceipt(msg)
            usersList.append([username, password, utype])
            context= {'data':'New user details added<br/>'+str(tx_receipt)}
            return render(request, 'Register.html', context)
        else:
            context= {'data':'Given username already exists'}
            return render(request, 'Register.html', context)

    
