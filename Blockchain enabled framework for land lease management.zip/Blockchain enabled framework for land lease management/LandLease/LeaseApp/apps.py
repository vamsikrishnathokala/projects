from django.apps import AppConfig


class LeaseappConfig(AppConfig):
    name = 'LeaseApp'
