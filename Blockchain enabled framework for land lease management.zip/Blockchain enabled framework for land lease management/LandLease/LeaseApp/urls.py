from django.urls import path

from . import views

urlpatterns = [path("index.html", views.index, name="index"),
               path("AdminLogin.html", views.AdminLogin, name="AdminLogin"),	      
               path("AdminLoginAction", views.AdminLoginAction, name="AdminLoginAction"),
               path("RegisterAction", views.RegisterAction, name="RegisterAction"),
               path("Register.html", views.Register, name="Register"),
               path("BankLogin.html", views.BankLogin, name="BankLogin"),	      
               path("BankLoginAction", views.BankLoginAction, name="BankLoginAction"),
	       path("AddProperty.html", views.AddProperty, name="AddProperty"),	      
               path("AddPropertyAction", views.AddPropertyAction, name="AddPropertyAction"),
	       path("ViewProperty", views.ViewProperty, name="ViewProperty"),
	       path("RequestLease.html", views.RequestLease, name="RequestLease"),	      
               path("RequestLeaseAction", views.RequestLeaseAction, name="RequestLeaseAction"),
	       path("PropertyValidation.html", views.PropertyValidation, name="PropertyValidation"),	      
               path("PropertyValidationAction", views.PropertyValidationAction, name="PropertyValidationAction"),
	       path("AdminMap", views.AdminMap, name="AdminMap"),
]
